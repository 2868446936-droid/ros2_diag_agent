# ROS 2 异常诊断与联调 Agent

基于 Claude Opus 4.7 的 ROS 2 机器人开发智能诊断助手,面向机器人开发流程中的常见痛点:
节点崩溃、话题不通、TF 树异常、参数错配、日志难读等问题,自动定位根因并给出可执行修复建议。

## ✨ 核心特性

- **自适应思考(Adaptive Thinking)**:Claude 自动判断问题复杂度,深问题深想、浅问题秒答。
- **结构化工具调用(Tool Use)**:封装 `ros2 node/topic/service/param/doctor` 等命令为安全工具,
  Agent 可自主组合调用。
- **日志智能分析**:支持 `~/.ros/log` 目录批量解析、错误堆栈聚类、堆栈片段定位源码。
- **联调闭环**:诊断 → 给出修复脚本 → 用户确认 → 工具执行回归验证。
- **Prompt Caching**:大型系统提示与诊断知识库通过 ephemeral 缓存,长会话成本降低 ~90%。
- **流式输出**:Agent 思考与响应实时显示,遵循 `claude-opus-4-7` 1M 上下文窗口。

## 📦 安装

```bash
# 1. 安装 Python 依赖(无需提前安装 ROS 2 即可运行 Mock 模式)
pip install -r requirements.txt

# 2. 配置 API Key
cp .env.example .env
# 编辑 .env,填入 ANTHROPIC_API_KEY

# 3.(可选)在已安装 ROS 2 的机器上 source 环境
source /opt/ros/humble/setup.bash
```

## 🚀 快速开始

### 交互式诊断

```bash
python -m ros2_diag_agent.cli
```

```
[ROS 2 Diag] > 我的 /cmd_vel 话题没有数据,机器人不动了
```

### 单次诊断(非交互)

```bash
python -m ros2_diag_agent.cli --once "tf 树里 base_link 找不到 odom 的变换"
```

### 离线日志分析

```bash
python -m ros2_diag_agent.cli --log examples/sample_log.txt
```

### Mock 模式(无 ROS 2 环境调试)

```bash
python -m ros2_diag_agent.cli --mock
```

## 🧰 内置工具

| 工具 | 说明 |
|------|------|
| `list_nodes` | 列出当前所有运行节点 |
| `list_topics` | 列出话题及其消息类型 |
| `topic_info` | 查看话题发布者/订阅者、频率(`ros2 topic hz`) |
| `topic_echo_once` | 抓取一帧话题数据用于排查格式异常 |
| `node_info` | 查看节点的发布/订阅/服务/参数 |
| `list_params` | 列出节点参数 |
| `get_param` | 读取参数值 |
| `tf_frames` | 输出 tf2 frames PDF 路径并解析 |
| `check_tf` | 查询两 frame 间是否有变换 |
| `ros2_doctor` | 运行 `ros2 doctor --report` |
| `read_log_file` | 读取并解析 ROS 2 日志文件 |
| `grep_logs` | 在最近日志中按关键字检索 |
| `run_diagnostic_script` | 在用户确认后执行诊断/修复脚本(白名单) |

## 🏗️ 项目结构

```
ros2_diag_agent/
├── README.md
├── requirements.txt
├── .env.example
├── ros2_diag_agent/
│   ├── __init__.py
│   ├── agent.py          # Claude 主循环 + 工具运行器
│   ├── cli.py            # 命令行入口
│   ├── tools.py          # 工具定义(@beta_tool)
│   ├── ros2_utils.py     # ROS 2 命令封装(含 Mock)
│   ├── log_parser.py     # 日志聚类与堆栈解析
│   └── prompts.py        # 系统提示与诊断知识库
├── examples/
│   ├── sample_log.txt
│   └── example_session.md
├── tests/
│   └── test_tools.py
└── docs/
    └── ARCHITECTURE.md
```

## ⚙️ 设计要点

1. **模型选择**:默认 `claude-opus-4-7`,长上下文 + 自适应思考最契合机器人多线索诊断场景。
2. **安全边界**:`run_diagnostic_script` 仅允许白名单脚本,且执行前要求 Agent 显式申请用户确认。
3. **Prompt Caching**:系统提示 + 诊断知识库放在最稳定的 prefix,使用 1h TTL ephemeral cache。
4. **错误兜底**:工具失败统一返回 `{"is_error": true, "message": ...}`,Agent 可自我纠正而非直接放弃。

## 📜 License

MIT
