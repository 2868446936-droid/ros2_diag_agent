"""ROS 2 异常诊断与联调 Agent。"""

__version__ = "0.1.0"
