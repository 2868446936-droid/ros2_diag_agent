"""ROS 2 诊断 Agent 主循环。

使用 claude-opus-4-7 + adaptive thinking + streaming + prompt caching。
通过 beta tool_runner 自动处理工具调用循环。
"""

from __future__ import annotations

import os
from typing import Optional

import anthropic
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.rule import Rule

from .prompts import build_system_messages
from .tools import ALL_TOOLS

console = Console()

# ── 默认配置 ──────────────────────────────────────────────────────────────────

DEFAULT_MODEL = os.environ.get("ROS2_DIAG_MODEL", "claude-opus-4-7")
MAX_TOKENS = 8192


# ── Agent 类 ──────────────────────────────────────────────────────────────────

class ROS2DiagAgent:
    """ROS 2 异常诊断 Agent。

    维护多轮对话历史，每轮调用带流式输出的 tool_runner。
    """

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        verbose: bool = False,
    ) -> None:
        self.model = model
        self.verbose = verbose
        self.client = anthropic.Anthropic()
        self.messages: list[dict] = []
        self.system = build_system_messages()
        self._turn_count = 0

    # ── 单轮诊断 ──────────────────────────────────────────────────────────────

    def run_turn(self, user_input: str) -> str:
        """提交一条用户消息，返回 Claude 的最终文本响应。

        流式输出会实时打印到终端；工具调用由 tool_runner 自动处理。
        每轮结束后把完整对话追加到 self.messages 以维持上下文。
        """
        self._turn_count += 1
        self.messages.append({"role": "user", "content": user_input})

        # tool_runner 迭代器：每次迭代对应一次 Claude 响应
        # 当 Claude 不再调用工具时循环结束
        runner = self.client.beta.messages.tool_runner(
            model=self.model,
            max_tokens=MAX_TOKENS,
            thinking={"type": "adaptive"},
            system=self.system,
            tools=ALL_TOOLS,
            messages=self.messages,
        )

        final_text = ""
        tool_calls_this_turn: list[str] = []

        for message in runner:
            # 处理当前 BetaMessage 中的内容块
            for block in message.content:
                if block.type == "thinking":
                    if self.verbose and block.thinking:
                        console.print(
                            Panel(
                                block.thinking,
                                title="[dim]🤔 Thinking[/dim]",
                                border_style="dim",
                            )
                        )
                elif block.type == "tool_use":
                    tool_name = block.name
                    tool_calls_this_turn.append(tool_name)
                    console.print(
                        f"  [cyan]🔧 {tool_name}[/cyan]",
                        highlight=False,
                    )
                    if self.verbose:
                        import json
                        console.print(
                            f"    [dim]{json.dumps(block.input, ensure_ascii=False)}[/dim]"
                        )
                elif block.type == "text" and block.text:
                    # 把文本流式输出到终端
                    console.print(Markdown(block.text))
                    final_text += block.text

            # 把每次 Claude 响应追加到历史（tool_result 由 tool_runner 自动追加）
            # tool_runner 内部已处理消息历史，这里只需记录最终 assistant 回复
            if message.stop_reason in ("end_turn", "max_tokens"):
                # 将最终助手消息加入我们自己的历史
                self.messages.append(
                    {"role": "assistant", "content": message.content}
                )

        if tool_calls_this_turn and self.verbose:
            console.print(
                f"  [dim]Used tools: {', '.join(tool_calls_this_turn)}[/dim]"
            )

        return final_text

    def run_once(self, query: str) -> str:
        """单次非交互诊断（不保留历史）。"""
        return self.run_turn(query)

    def analyze_log_file(self, log_path: str) -> str:
        """分析给定日志文件的快捷方法。"""
        prompt = (
            f"Please analyze the ROS 2 log file at '{log_path}'. "
            "Use read_log_file to parse it, identify the root cause of any errors, "
            "and suggest concrete fixes."
        )
        return self.run_turn(prompt)

    def reset(self) -> None:
        """清除对话历史，开始新诊断会话。"""
        self.messages = []
        self._turn_count = 0


# ── 交互式会话 ────────────────────────────────────────────────────────────────

def run_interactive(
    mock: bool = False,
    model: str = DEFAULT_MODEL,
    verbose: bool = False,
) -> None:
    """启动交互式诊断 REPL。"""
    from . import ros2_utils as ru

    if mock:
        ru.set_mock_mode(True)
        console.print("[yellow]Running in Mock mode — no real ROS 2 required.[/yellow]")

    agent = ROS2DiagAgent(model=model, verbose=verbose)

    console.print(
        Panel(
            "[bold green]ROS 2 Diagnostic Agent[/bold green]\n"
            f"Model: {model}  |  Tools: {len(ALL_TOOLS)}\n"
            "Type your question, or 'exit' / Ctrl-C to quit.\n"
            "Commands: [bold]/reset[/bold] clear history  [bold]/mock[/bold] toggle mock",
            title="Welcome",
            border_style="green",
        )
    )

    while True:
        try:
            user_input = console.input("\n[bold blue][ROS 2 Diag][/bold blue] > ").strip()
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "q"):
            console.print("[dim]Goodbye![/dim]")
            break

        if user_input == "/reset":
            agent.reset()
            console.print("[dim]Conversation history cleared.[/dim]")
            continue

        if user_input == "/mock":
            current = ru.is_mock_mode()
            ru.set_mock_mode(not current)
            state = "enabled" if not current else "disabled"
            console.print(f"[dim]Mock mode {state}.[/dim]")
            continue

        console.print(Rule(style="dim"))
        try:
            agent.run_turn(user_input)
        except anthropic.APIError as e:
            console.print(f"[red]API error: {e}[/red]")
        except Exception as e:
            console.print(f"[red]Unexpected error: {e}[/red]")
            if verbose:
                import traceback
                traceback.print_exc()
