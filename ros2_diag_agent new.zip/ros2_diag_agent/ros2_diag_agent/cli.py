"""命令行入口：python -m ros2_diag_agent.cli"""

from __future__ import annotations

import argparse
import os
import sys

from rich.console import Console

console = Console()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="ros2-diag-agent",
        description="ROS 2 异常诊断 Agent（基于 Claude Opus 4.7）",
    )
    parser.add_argument(
        "--once",
        metavar="QUERY",
        help="单次诊断（非交互），完成后退出",
    )
    parser.add_argument(
        "--log",
        metavar="FILE",
        help="直接分析给定的 ROS 2 日志文件",
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        default=bool(os.environ.get("ROS2_DIAG_MOCK")),
        help="Mock 模式：无需 ROS 2 环境即可运行",
    )
    parser.add_argument(
        "--model",
        default=os.environ.get("ROS2_DIAG_MODEL", "claude-opus-4-7"),
        help="Claude 模型 ID（默认 claude-opus-4-7）",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="显示 thinking 内容与工具调用详情",
    )

    args = parser.parse_args()

    # 延迟导入，避免加载时校验 API Key
    try:
        from .agent import ROS2DiagAgent, run_interactive
        from . import ros2_utils as ru
    except ImportError as e:
        console.print(f"[red]Import error: {e}[/red]")
        console.print("[dim]Run: pip install -r requirements.txt[/dim]")
        sys.exit(1)

    if args.mock:
        ru.set_mock_mode(True)

    if args.once:
        agent = ROS2DiagAgent(model=args.model, verbose=args.verbose)
        result = agent.run_once(args.once)
        sys.exit(0)

    if args.log:
        agent = ROS2DiagAgent(model=args.model, verbose=args.verbose)
        agent.analyze_log_file(args.log)
        sys.exit(0)

    # 默认：交互式
    run_interactive(mock=args.mock, model=args.model, verbose=args.verbose)


if __name__ == "__main__":
    main()
