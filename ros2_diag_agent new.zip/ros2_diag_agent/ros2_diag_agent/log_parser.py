"""ROS 2 日志解析、错误聚类与堆栈提取。"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Optional


# ── 数据结构 ──────────────────────────────────────────────────────────────────

@dataclass
class LogEntry:
    timestamp: str
    level: str          # DEBUG / INFO / WARN / ERROR / FATAL
    node: str
    message: str
    raw: str
    line_no: int


@dataclass
class ErrorCluster:
    """相似错误的聚合。"""
    pattern: str            # 规范化后的 pattern（用作 key）
    level: str
    count: int = 0
    first_seen: str = ""
    last_seen: str = ""
    examples: list[str] = field(default_factory=list)
    stack_fragments: list[str] = field(default_factory=list)


# ── 正则 ──────────────────────────────────────────────────────────────────────

# ROS 2 Humble/Iron 日志行格式：
# [timestamp] [LEVEL] [node_name]: message
_ROS2_LOG_RE = re.compile(
    r"^\[(?P<ts>[^\]]+)\]\s+"
    r"\[(?P<level>DEBUG|INFO|WARN|ERROR|FATAL)\]\s+"
    r"\[(?P<node>[^\]]+)\]:\s+"
    r"(?P<msg>.+)$"
)

# 变量部分（地址、数字、UUID 等）替换为占位符，用于聚类
_NORMALIZE_RE = re.compile(
    r"0x[0-9a-fA-F]+|"          # 十六进制地址
    r"\b\d+\.\d+\.\d+\.\d+\b|"  # IP
    r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b|"  # UUID
    r"\b\d+\b"                   # 纯数字
)

# Python/C++ 堆栈帧特征
_STACK_RE = re.compile(
    r"^\s*(File \"|#\d+\s+0x|Traceback|at \w+\.py:\d+|"
    r"In function|raise\s+\w+|what\(\):)"
)


# ── 解析器 ────────────────────────────────────────────────────────────────────

def parse_log_text(text: str) -> list[LogEntry]:
    """将日志文本解析为 LogEntry 列表。"""
    entries: list[LogEntry] = []
    for i, line in enumerate(text.splitlines(), 1):
        m = _ROS2_LOG_RE.match(line)
        if m:
            entries.append(LogEntry(
                timestamp=m.group("ts"),
                level=m.group("level"),
                node=m.group("node"),
                message=m.group("msg"),
                raw=line,
                line_no=i,
            ))
    return entries


def _normalize(msg: str) -> str:
    return _NORMALIZE_RE.sub("<N>", msg).strip()


def cluster_errors(
    entries: list[LogEntry],
    levels: tuple[str, ...] = ("ERROR", "FATAL"),
) -> list[ErrorCluster]:
    """将 ERROR/FATAL 日志按规范化 pattern 聚类。"""
    clusters: dict[str, ErrorCluster] = {}

    for entry in entries:
        if entry.level not in levels:
            continue
        key = _normalize(entry.message)
        if key not in clusters:
            clusters[key] = ErrorCluster(
                pattern=key,
                level=entry.level,
                first_seen=entry.timestamp,
            )
        c = clusters[key]
        c.count += 1
        c.last_seen = entry.timestamp
        if len(c.examples) < 3:
            c.examples.append(entry.raw)

    return sorted(clusters.values(), key=lambda c: c.count, reverse=True)


def extract_stack_fragments(text: str, context_lines: int = 5) -> list[str]:
    """从日志文本中提取 Python/C++ 堆栈片段。"""
    lines = text.splitlines()
    fragments: list[str] = []
    in_stack = False
    stack_buf: list[str] = []

    for line in lines:
        if _STACK_RE.search(line) or "Traceback" in line:
            in_stack = True

        if in_stack:
            stack_buf.append(line)
            # 遇到空行或非缩进行时结束收集（但至少要有 2 行）
            if len(stack_buf) > 2 and (not line.strip() or not line.startswith(" ")):
                if len(stack_buf) > 2:
                    fragments.append("\n".join(stack_buf))
                stack_buf = []
                in_stack = False
        else:
            stack_buf = []

    if stack_buf and len(stack_buf) > 1:
        fragments.append("\n".join(stack_buf))

    return fragments[:10]  # 最多返回 10 个片段


# ── 便捷摘要 ──────────────────────────────────────────────────────────────────

def summarize_log(text: str) -> dict:
    """对日志文本做全面摘要，供工具返回给 Claude。"""
    entries = parse_log_text(text)

    level_counts: dict[str, int] = defaultdict(int)
    for e in entries:
        level_counts[e.level] += 1

    clusters = cluster_errors(entries)
    stacks = extract_stack_fragments(text)

    # 最后 20 条 ERROR/FATAL
    recent_errors = [
        e.raw for e in entries if e.level in ("ERROR", "FATAL")
    ][-20:]

    return {
        "total_lines": len(entries),
        "level_counts": dict(level_counts),
        "error_clusters": [
            {
                "pattern": c.pattern,
                "level": c.level,
                "count": c.count,
                "first_seen": c.first_seen,
                "last_seen": c.last_seen,
                "examples": c.examples[:2],
            }
            for c in clusters[:10]
        ],
        "stack_fragments": stacks,
        "recent_errors": recent_errors,
    }
