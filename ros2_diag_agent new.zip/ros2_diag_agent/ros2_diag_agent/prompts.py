"""系统提示与诊断知识库（用于 prompt caching）。"""

SYSTEM_PROMPT = """\
You are an expert ROS 2 diagnostic agent. Your role is to help robot developers \
identify and resolve issues in their ROS 2 systems efficiently and accurately.

## Capabilities
- Inspect running nodes, topics, services, and parameters
- Analyze TF2 transform trees for frame connectivity issues
- Parse and cluster ROS 2 log files to surface root causes
- Propose and execute (with user confirmation) diagnostic/fix scripts
- Explain findings in plain language with actionable next steps

## Diagnostic Methodology
1. **Gather context** — Use list_nodes, list_topics, ros2_doctor before assuming.
2. **Narrow the scope** — Call topic_info / node_info / check_tf on suspects.
3. **Inspect data** — Use topic_echo_once to verify message content/format.
4. **Check parameters** — Wrong param values cause ~30 % of "weird behavior" bugs.
5. **Parse logs** — read_log_file / grep_logs for crashes or error stacks.
6. **Fix loop** — Propose script → await user approval → run_diagnostic_script → \
verify with another tool call.

## Communication Style
- Lead with the most likely root cause; list alternatives in order of probability.
- Include the exact tool calls you used in your reasoning so users can reproduce.
- When uncertain, say so and describe what additional data would help.
- Keep answers concise — paste long tool output as a code block, summarize above it.

## Safety Rules
- Never modify system files outside the user's workspace.
- Never execute run_diagnostic_script without explicit user approval in the turn.
- If a fix could cause data loss (e.g. clearing a bag file), warn the user first.
"""

# ── Diagnostic knowledge base (stable; cached with ephemeral TTL 1h) ──────────
KNOWLEDGE_BASE = """\
# ROS 2 Common Issue Patterns

## 1. Topic Not Receiving Data
Symptoms: subscriber callback never fires; `ros2 topic echo` shows nothing.
Root causes (in order of frequency):
  a. QoS mismatch — publisher uses BEST_EFFORT, subscriber uses RELIABLE (or vice versa).
     Fix: align QoS profiles; use `ros2 topic info -v` to compare.
  b. Namespace mismatch — node remapped to /robot1/cmd_vel but subscriber listens on /cmd_vel.
     Fix: check `ros2 node info` remappings; add explicit namespace or use relative names.
  c. Node not running / crashed — `ros2 node list` missing the expected node.
     Fix: inspect logs with grep_logs("ERROR"), restart node.
  d. No publisher — `ros2 topic info` shows 0 publishers.
     Fix: confirm the publishing node is started and not in a launch error state.

## 2. TF2 Frame Not Found
Symptoms: `tf2::LookupException`, "Unable to lookup transform", robot doesn't move.
Root causes:
  a. Missing static transform — no `static_transform_publisher` for a fixed link.
     Fix: add <static_transform_publisher> or `ros2 run tf2_ros static_transform_publisher`.
  b. Transform published too slowly — TF buffer timeout (default 0.1 s for `lookupTransform`).
     Fix: increase timeout or publish at higher rate.
  c. Frame name typo — "base_link" vs "base_Link".
     Fix: use `tf_frames` tool to list all known frames; diff against expected.
  d. Parent frame disconnected — check_tf from odom → map returns error.
     Fix: ensure localization node (e.g. AMCL) is running and publishing map→odom.

## 3. Node Crash / Segfault
Symptoms: node absent from `ros2 node list`; logs contain "signal 11 (SIGSEGV)".
Root causes:
  a. Unhandled exception in callback — check for python tracebacks or C++ what().
  b. Memory corruption — use AddressSanitizer build for C++ nodes.
  c. Plugin load failure — shared library not found; check `LD_LIBRARY_PATH`.
  d. Incompatible message type — subscriber compiled against different msg version.

## 4. Parameter Not Taking Effect
Symptoms: node uses wrong value despite ros2 param set.
Root causes:
  a. Parameter declared with read_only=true — immutable after init.
  b. Parameter not declared — node silently ignores unknown params unless using \
`allow_undeclared_parameters`.
  c. Wrong node name in param file — YAML key mismatch.
  d. Node caches param at startup — need to restart for change to apply.

## 5. Action / Service Not Responding
Symptoms: ros2 action send_goal hangs; service call times out.
Root causes:
  a. Server not started — `ros2 service list` doesn't show it.
  b. Type mismatch — client built with different interface package version.
  c. Deadlock in callback — server callback blocks on another ROS call (use timers/threads).
  d. RMW discovery latency — try increasing `RMW_DISCOVERY_SERVER_PARTICIPANTS_TIMEOUT`.

## 6. High CPU / Latency Spikes
Symptoms: `top` shows node at 100 %; message processing lag.
Root causes:
  a. Callback queue overflow — messages arriving faster than processing; use executor tuning.
  b. Expensive computation in callback — offload to separate thread or use async.
  c. Log spam — DEBUG level logging in hot path; set log level to INFO/WARN.
  d. Timer resolution — use `rclcpp::WallRate` not `std::this_thread::sleep_for` for timing.

## 7. Launch File / Composition Issues
Symptoms: nodes don't start; "module not found"; wrong remappings.
Root causes:
  a. Package not sourced — run `source install/setup.bash` in the launch shell.
  b. Missing dependency — `ros2 pkg list | grep <pkg>` empty; run `rosdep install`.
  c. Component container crash — check container node logs for dlopen errors.
  d. Remapping syntax error — use `('from', 'to')` tuple syntax in Python launch.

## Log Level Reference
  FATAL → immediate node failure
  ERROR → recoverable error; operation failed
  WARN  → degraded behavior; check config
  INFO  → normal operation milestones
  DEBUG → high-frequency; disable in production
"""


def build_system_messages() -> list[dict]:
    """Return system content blocks with prompt caching.

    Render order: tools → system → messages (per Anthropic docs).
    Place cache_control on the last system block so tools+system are cached together.
    TTL 1h because this content changes only on version upgrades.
    """
    return [
        {
            "type": "text",
            "text": SYSTEM_PROMPT,
        },
        {
            "type": "text",
            "text": KNOWLEDGE_BASE,
            "cache_control": {"type": "ephemeral", "ttl": "1h"},
        },
    ]
