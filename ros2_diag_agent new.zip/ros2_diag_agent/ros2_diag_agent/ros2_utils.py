"""ROS 2 命令封装。

所有对 ros2 CLI 的调用都通过本模块，支持 Mock 模式（无 ROS 2 环境时使用）。
Mock 数据模拟一个小型移动机器人系统，便于演示和测试。
"""

from __future__ import annotations

import os
import subprocess
import textwrap
from typing import Optional

# ── Mock 数据 ──────────────────────────────────────────────────────────────────

_MOCK_NODES = """\
/controller_manager
/joint_state_broadcaster
/diff_drive_controller
/robot_state_publisher
/slam_toolbox
/nav2_planner_server
/amcl
/rviz2
"""

_MOCK_TOPICS = """\
/cmd_vel [geometry_msgs/msg/Twist]
/odom [nav_msgs/msg/Odometry]
/scan [sensor_msgs/msg/LaserScan]
/tf [tf2_msgs/msg/TFMessage]
/tf_static [tf2_msgs/msg/TFMessage]
/joint_states [sensor_msgs/msg/JointState]
/map [nav_msgs/msg/OccupancyGrid]
/goal_pose [geometry_msgs/msg/PoseStamped]
/diagnostics [diagnostic_msgs/msg/DiagnosticArray]
"""

_MOCK_TOPIC_INFO: dict[str, str] = {
    "/cmd_vel": textwrap.dedent("""\
        Type: geometry_msgs/msg/Twist
        Publisher count: 0
        Subscription count: 1
        Subscribers:
          /diff_drive_controller
        Publishers: (none)
        """),
    "/odom": textwrap.dedent("""\
        Type: nav_msgs/msg/Odometry
        Publisher count: 1
        Subscription count: 2
        Publishers:
          /diff_drive_controller
        Subscribers:
          /slam_toolbox
          /amcl
        """),
    "/scan": textwrap.dedent("""\
        Type: sensor_msgs/msg/LaserScan
        Publisher count: 1
        Subscription count: 1
        Publishers:
          /rplidar_node
        Subscribers:
          /slam_toolbox
        """),
}

_MOCK_TOPIC_ECHO: dict[str, str] = {
    "/cmd_vel": textwrap.dedent("""\
        linear:
          x: 0.0
          y: 0.0
          z: 0.0
        angular:
          x: 0.0
          y: 0.0
          z: 0.0
        ---
        """),
    "/odom": textwrap.dedent("""\
        header:
          stamp: {sec: 1700000000, nanosec: 0}
          frame_id: odom
        child_frame_id: base_link
        pose:
          pose:
            position: {x: 0.0, y: 0.0, z: 0.0}
            orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}
        ---
        """),
}

_MOCK_NODE_INFO: dict[str, str] = {
    "/diff_drive_controller": textwrap.dedent("""\
        Node name: diff_drive_controller
        Namespace: /
        Node type: controller_manager/diff_drive_controller
        Publishers:
          /odom: nav_msgs/msg/Odometry
          /tf: tf2_msgs/msg/TFMessage
        Subscribers:
          /cmd_vel: geometry_msgs/msg/Twist
          /joint_states: sensor_msgs/msg/JointState
        Service Servers:
          /diff_drive_controller/describe_parameters
          /diff_drive_controller/get_parameter_types
          /diff_drive_controller/get_parameters
          /diff_drive_controller/list_parameters
          /diff_drive_controller/set_parameters
        Parameters:
          left_wheel_names: ['left_wheel_joint']
          right_wheel_names: ['right_wheel_joint']
          wheel_separation: 0.5
          wheel_radius: 0.1
          publish_rate: 50.0
        """),
    "/amcl": textwrap.dedent("""\
        Node name: amcl
        Namespace: /
        Publishers:
          /amcl_pose: geometry_msgs/msg/PoseWithCovarianceStamped
          /particlecloud: nav2_msgs/msg/ParticleCloud
          /tf: tf2_msgs/msg/TFMessage
        Subscribers:
          /scan: sensor_msgs/msg/LaserScan
          /map: nav_msgs/msg/OccupancyGrid
          /initialpose: geometry_msgs/msg/PoseWithCovarianceStamped
        """),
}

_MOCK_PARAMS: dict[str, str] = {
    "/diff_drive_controller": textwrap.dedent("""\
        /diff_drive_controller:
          left_wheel_names
          right_wheel_names
          wheel_separation
          wheel_radius
          publish_rate
          use_stamped_vel
          odom_frame_id
          base_frame_id
        """),
}

_MOCK_TF_FRAMES = textwrap.dedent("""\
    TF frames:
      map
      odom
      base_link
      base_footprint
      laser_frame
      left_wheel
      right_wheel

    Connections:
      map -> odom (amcl, 50 Hz)
      odom -> base_link (diff_drive_controller, 50 Hz)
      base_link -> base_footprint (robot_state_publisher, static)
      base_link -> laser_frame (robot_state_publisher, static)
      base_link -> left_wheel (diff_drive_controller, 50 Hz)
      base_link -> right_wheel (diff_drive_controller, 50 Hz)
    """)

_MOCK_DOCTOR = textwrap.dedent("""\
    ros2 doctor report
    ==================

    Platform Information
    --------------------
    OS: Linux-5.15.0-x86_64
    ROS distro: humble
    Python: 3.10.12

    Network Configuration
    ---------------------
    ROS_DOMAIN_ID: 0 (default)
    ROS_LOCALHOST_ONLY: not set

    Package Versions
    ----------------
    rclpy: 3.3.9
    rclcpp: 16.0.8

    Warnings:
    [WARN] /scan topic has no subscribers besides slam_toolbox; \
navigation stack may not be receiving lidar data.
    [WARN] ROS_DOMAIN_ID is 0 — consider setting a non-default value \
to avoid conflicts on shared networks.
    """)

# ── 执行工具 ──────────────────────────────────────────────────────────────────

_MOCK_MODE: bool = False


def set_mock_mode(enabled: bool) -> None:
    """切换 Mock 模式。"""
    global _MOCK_MODE
    _MOCK_MODE = enabled


def is_mock_mode() -> bool:
    return _MOCK_MODE


def _run(cmd: list[str], timeout: int = 10) -> tuple[str, str, int]:
    """运行命令，返回 (stdout, stderr, returncode)。"""
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.stdout, proc.stderr, proc.returncode
    except FileNotFoundError:
        return "", f"Command not found: {cmd[0]}", 127
    except subprocess.TimeoutExpired:
        return "", f"Command timed out after {timeout}s", 124


# ── 公共 API ──────────────────────────────────────────────────────────────────

def list_nodes() -> dict:
    if _MOCK_MODE:
        return {"output": _MOCK_NODES.strip()}
    out, err, rc = _run(["ros2", "node", "list"])
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def list_topics() -> dict:
    if _MOCK_MODE:
        return {"output": _MOCK_TOPICS.strip()}
    out, err, rc = _run(["ros2", "topic", "list", "-t"])
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def topic_info(topic_name: str) -> dict:
    """返回话题的 info + Hz（Mock 模式返回预设数据）。"""
    if _MOCK_MODE:
        info = _MOCK_TOPIC_INFO.get(
            topic_name,
            f"Topic '{topic_name}' not found in mock data.\n",
        )
        hz = "average rate: 10.000 Hz\n" if topic_name != "/cmd_vel" else "no publishers\n"
        return {"info": info.strip(), "hz": hz.strip()}

    out_info, err_info, rc_info = _run(["ros2", "topic", "info", "-v", topic_name])
    if rc_info != 0:
        return {"is_error": True, "message": err_info or out_info}

    # Hz 测量运行 3 s，避免阻塞太久
    out_hz, _, _ = _run(
        ["ros2", "topic", "hz", "--window", "5", topic_name],
        timeout=6,
    )
    return {"info": out_info.strip(), "hz": out_hz.strip()}


def topic_echo_once(topic_name: str) -> dict:
    if _MOCK_MODE:
        data = _MOCK_TOPIC_ECHO.get(
            topic_name,
            f"No mock data for '{topic_name}'\n",
        )
        return {"output": data.strip()}
    out, err, rc = _run(
        ["ros2", "topic", "echo", "--once", topic_name],
        timeout=8,
    )
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def node_info(node_name: str) -> dict:
    if _MOCK_MODE:
        info = _MOCK_NODE_INFO.get(
            node_name,
            f"Node '{node_name}' not found in mock data.\n",
        )
        return {"output": info.strip()}
    out, err, rc = _run(["ros2", "node", "info", node_name])
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def list_params(node_name: str) -> dict:
    if _MOCK_MODE:
        params = _MOCK_PARAMS.get(
            node_name,
            f"No params found for '{node_name}' in mock data.\n",
        )
        return {"output": params.strip()}
    out, err, rc = _run(["ros2", "param", "list", node_name])
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def get_param(node_name: str, param_name: str) -> dict:
    if _MOCK_MODE:
        mock_vals: dict[str, dict[str, str]] = {
            "/diff_drive_controller": {
                "wheel_separation": "Double value is: 0.5",
                "wheel_radius": "Double value is: 0.1",
                "publish_rate": "Double value is: 50.0",
            }
        }
        val = mock_vals.get(node_name, {}).get(
            param_name,
            f"Parameter '{param_name}' not found in mock data.",
        )
        return {"output": val}
    out, err, rc = _run(["ros2", "param", "get", node_name, param_name])
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def tf_frames() -> dict:
    if _MOCK_MODE:
        return {"output": _MOCK_TF_FRAMES.strip()}
    # 生成 PDF 并解析 — 先尝试 view_frames，再读取生成的文件内容
    out, err, rc = _run(
        ["ros2", "run", "tf2_tools", "view_frames"],
        timeout=15,
    )
    return {"output": out.strip() or err.strip(), "is_error": rc != 0}


def check_tf(source_frame: str, target_frame: str) -> dict:
    if _MOCK_MODE:
        known = {"map", "odom", "base_link", "base_footprint", "laser_frame"}
        if source_frame in known and target_frame in known:
            return {
                "output": (
                    f"At time 0.0\n"
                    f"- Translation: [0.000, 0.000, 0.000]\n"
                    f"- Rotation: in Quaternion [0.000, 0.000, 0.000, 1.000]\n"
                )
            }
        return {
            "is_error": True,
            "message": (
                f"Could not find a connection between '{source_frame}' and "
                f"'{target_frame}' because they are not in the same tree."
            ),
        }
    out, err, rc = _run(
        ["ros2", "run", "tf2_ros", "tf2_echo", source_frame, target_frame],
        timeout=5,
    )
    if rc != 0:
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def ros2_doctor() -> dict:
    if _MOCK_MODE:
        return {"output": _MOCK_DOCTOR.strip()}
    out, err, rc = _run(["ros2", "doctor", "--report"], timeout=30)
    if rc not in (0, 1):  # doctor 返回 1 表示有警告，仍然有用
        return {"is_error": True, "message": err or out}
    return {"output": out.strip()}


def read_log_file(path: str) -> dict:
    """读取并返回日志文件内容（最多 4 000 行）。"""
    # 展开 ~
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return {"is_error": True, "message": f"File not found: {path}"}
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        if len(lines) > 4000:
            truncated = True
            lines = lines[-4000:]  # 保留最近的行
        else:
            truncated = False
        content = "".join(lines)
        return {
            "path": path,
            "lines": len(lines),
            "truncated": truncated,
            "content": content,
        }
    except OSError as e:
        return {"is_error": True, "message": str(e)}


def grep_logs(keyword: str, max_files: int = 5) -> dict:
    """在最近的 ROS 2 日志目录中搜索关键字。"""
    log_dir = os.path.expanduser(
        os.environ.get("ROS_LOG_DIR", "~/.ros/log")
    )

    if _MOCK_MODE:
        return {
            "matches": [
                f"[{log_dir}/latest/my_node.log:42] [ERROR] [my_node]: "
                f"Failed to load parameter file: {keyword} not found"
            ]
        }

    if not os.path.isdir(log_dir):
        return {"is_error": True, "message": f"Log directory not found: {log_dir}"}

    # 找最近修改的子目录
    try:
        subdirs = sorted(
            (
                os.path.join(log_dir, d)
                for d in os.listdir(log_dir)
                if os.path.isdir(os.path.join(log_dir, d))
            ),
            key=os.path.getmtime,
            reverse=True,
        )[:max_files]
    except OSError as e:
        return {"is_error": True, "message": str(e)}

    matches: list[str] = []
    for subdir in subdirs:
        for root, _, files in os.walk(subdir):
            for fname in files:
                if not fname.endswith(".log"):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, encoding="utf-8", errors="replace") as f:
                        for i, line in enumerate(f, 1):
                            if keyword.lower() in line.lower():
                                matches.append(f"[{fpath}:{i}] {line.rstrip()}")
                                if len(matches) >= 200:
                                    break
                except OSError:
                    continue
            if len(matches) >= 200:
                break

    return {"keyword": keyword, "matches": matches[:200]}


# ── 白名单脚本执行 ────────────────────────────────────────────────────────────

# 允许执行的脚本前缀/名称（根据需要扩展）
_SCRIPT_ALLOWLIST = {
    "ros2_check_network.sh",
    "ros2_reset_params.py",
    "check_transform_tree.sh",
    "restart_controller.sh",
}


def run_diagnostic_script(
    script_path: str,
    args: Optional[list[str]] = None,
) -> dict:
    """执行诊断/修复脚本（仅限白名单）。

    调用者（agent.py）在调用前必须已获得用户确认。
    """
    script_name = os.path.basename(script_path)
    if script_name not in _SCRIPT_ALLOWLIST:
        return {
            "is_error": True,
            "message": (
                f"Script '{script_name}' is not in the allowlist. "
                f"Allowed scripts: {sorted(_SCRIPT_ALLOWLIST)}"
            ),
        }

    if _MOCK_MODE:
        return {
            "output": f"[Mock] Would execute: {script_path} {' '.join(args or [])}"
        }

    cmd = [script_path] + (args or [])
    out, err, rc = _run(cmd, timeout=60)
    if rc != 0:
        return {"is_error": True, "message": err or out, "returncode": rc}
    return {"output": out.strip(), "returncode": rc}
