"""工具定义——使用 @beta_tool 装饰器。

每个工具都调用 ros2_utils 中对应的封装函数，并将结果格式化为字符串返回给 Claude。
工具失败时统一返回 is_error=True + message，让 Claude 自行纠正而非直接放弃。
"""

from __future__ import annotations

import json
from typing import Optional

import anthropic
from anthropic import beta_tool

from . import ros2_utils as ru
from .log_parser import summarize_log


def _fmt(result: dict) -> str:
    """将 dict 结果格式化为清晰文本。"""
    if result.get("is_error"):
        return f"[ERROR] {result.get('message', 'unknown error')}"
    # 优先返回 output 字段；否则 JSON 序列化
    if "output" in result:
        return result["output"]
    return json.dumps(result, ensure_ascii=False, indent=2)


# ── 节点 / 话题 ───────────────────────────────────────────────────────────────

@beta_tool
def list_nodes() -> str:
    """List all currently running ROS 2 nodes.

    Returns the node names, one per line.
    Use this to verify a node is alive or to enumerate available nodes.
    """
    return _fmt(ru.list_nodes())


@beta_tool
def list_topics() -> str:
    """List all active ROS 2 topics with their message types.

    Returns topic names and types in the format:
      /topic_name [package/msg/Type]
    Use this to discover available topics before calling topic_info.
    """
    return _fmt(ru.list_topics())


@beta_tool
def topic_info(topic_name: str) -> str:
    """Get detailed info about a ROS 2 topic: publishers, subscribers, and message rate.

    Args:
        topic_name: Full topic name, e.g. '/cmd_vel' or '/scan'.

    Returns info (publisher/subscriber count, QoS) and average publish rate (Hz).
    A publisher count of 0 means no one is publishing — a common cause of silent failures.
    """
    return _fmt(ru.topic_info(topic_name))


@beta_tool
def topic_echo_once(topic_name: str) -> str:
    """Capture a single message from a ROS 2 topic and return its content.

    Args:
        topic_name: Full topic name, e.g. '/odom'.

    Use this to inspect message field values and detect format mismatches or NaN/zero data.
    Blocks until one message arrives (up to 8 seconds).
    """
    return _fmt(ru.topic_echo_once(topic_name))


# ── 节点信息 / 参数 ───────────────────────────────────────────────────────────

@beta_tool
def node_info(node_name: str) -> str:
    """Get full info about a ROS 2 node: publishers, subscribers, services, and parameters.

    Args:
        node_name: Fully-qualified node name, e.g. '/diff_drive_controller'.

    Use this to verify a node's topic connections and detect remapping issues.
    """
    return _fmt(ru.node_info(node_name))


@beta_tool
def list_params(node_name: str) -> str:
    """List all declared parameters for a ROS 2 node.

    Args:
        node_name: Fully-qualified node name, e.g. '/amcl'.

    Use this to see which parameters are available before calling get_param.
    """
    return _fmt(ru.list_params(node_name))


@beta_tool
def get_param(node_name: str, param_name: str) -> str:
    """Read the current value of a parameter from a running ROS 2 node.

    Args:
        node_name: Fully-qualified node name, e.g. '/diff_drive_controller'.
        param_name: Parameter name, e.g. 'wheel_separation'.

    Returns the parameter type and value.
    """
    return _fmt(ru.get_param(node_name, param_name))


# ── TF ────────────────────────────────────────────────────────────────────────

@beta_tool
def tf_frames() -> str:
    """List all TF2 frames and their parent-child connections.

    Returns frame names and the transforms connecting them (publisher node, rate).
    Use this to detect missing or disconnected frames before calling check_tf.
    """
    return _fmt(ru.tf_frames())


@beta_tool
def check_tf(source_frame: str, target_frame: str) -> str:
    """Check whether a TF2 transform exists between two frames.

    Args:
        source_frame: Source frame ID, e.g. 'odom'.
        target_frame: Target frame ID, e.g. 'base_link'.

    Returns the translation and rotation if the transform exists,
    or an error message describing why it cannot be looked up.
    """
    return _fmt(ru.check_tf(source_frame, target_frame))


# ── 系统诊断 ──────────────────────────────────────────────────────────────────

@beta_tool
def ros2_doctor() -> str:
    """Run 'ros2 doctor --report' to get a system-wide health check.

    Returns platform info, network config, package versions, and any warnings.
    Use this at the start of a session to quickly rule out environmental issues.
    """
    return _fmt(ru.ros2_doctor())


# ── 日志 ──────────────────────────────────────────────────────────────────────

@beta_tool
def read_log_file(path: str) -> str:
    """Read and analyze a ROS 2 log file.

    Args:
        path: Path to the log file, e.g. '~/.ros/log/latest/my_node.log'.
              Supports ~ expansion.

    Returns a summary with:
    - Total line count and level distribution (DEBUG/INFO/WARN/ERROR/FATAL)
    - Top error patterns (clustered by similarity)
    - Extracted stack traces
    - The 20 most recent ERROR/FATAL lines
    """
    result = ru.read_log_file(path)
    if result.get("is_error"):
        return _fmt(result)

    summary = summarize_log(result["content"])
    # 把摘要和原始末尾日志合并
    lines = [
        f"=== Log summary: {result['path']} ===",
        f"Total lines parsed: {summary['total_lines']}",
        f"Level counts: {json.dumps(summary['level_counts'])}",
        "",
    ]

    if summary["error_clusters"]:
        lines.append("--- Error Clusters (top patterns) ---")
        for c in summary["error_clusters"]:
            lines.append(
                f"  [{c['level']}] x{c['count']}: {c['pattern']}\n"
                f"    first: {c['first_seen']}  last: {c['last_seen']}\n"
                + ("\n".join(f"    ex: {ex}" for ex in c["examples"]))
            )
        lines.append("")

    if summary["stack_fragments"]:
        lines.append("--- Stack Fragments ---")
        for sf in summary["stack_fragments"]:
            lines.append(sf)
            lines.append("---")

    if summary["recent_errors"]:
        lines.append("--- Recent Errors (last 20) ---")
        lines.extend(summary["recent_errors"])

    return "\n".join(lines)


@beta_tool
def grep_logs(keyword: str, max_files: int = 5) -> str:
    """Search the most recent ROS 2 log directories for a keyword.

    Args:
        keyword: Search term (case-insensitive), e.g. 'ERROR' or 'transform'.
        max_files: How many recent log subdirectories to search (default 5).

    Returns matching lines with their file path and line number.
    Useful for quickly finding where a specific error message originated.
    """
    result = ru.grep_logs(keyword, max_files)
    if result.get("is_error"):
        return _fmt(result)
    matches = result.get("matches", [])
    if not matches:
        return f"No matches for '{keyword}' in the last {max_files} log directories."
    header = f"Found {len(matches)} match(es) for '{keyword}':\n"
    return header + "\n".join(matches)


# ── 脚本执行 ──────────────────────────────────────────────────────────────────

@beta_tool
def run_diagnostic_script(script_path: str, args: Optional[list[str]] = None) -> str:
    """Execute a diagnostic or repair script from the allowlist.

    Args:
        script_path: Path to the script to run. Must be in the allowlist.
        args: Optional list of command-line arguments to pass to the script.

    IMPORTANT: Only call this tool AFTER the user has explicitly confirmed
    in the current turn that they want to run the script.
    The script is executed in the user's shell environment.
    Only scripts in the security allowlist are permitted.
    """
    return _fmt(ru.run_diagnostic_script(script_path, args or []))


# ── 工具列表（供 agent.py 使用）───────────────────────────────────────────────

ALL_TOOLS = [
    list_nodes,
    list_topics,
    topic_info,
    topic_echo_once,
    node_info,
    list_params,
    get_param,
    tf_frames,
    check_tf,
    ros2_doctor,
    read_log_file,
    grep_logs,
    run_diagnostic_script,
]
