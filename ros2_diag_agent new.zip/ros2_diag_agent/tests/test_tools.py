"""工具函数单元测试（使用 Mock 模式，无需 ROS 2 环境）。"""

from __future__ import annotations

import pytest

from ros2_diag_agent import ros2_utils as ru
from ros2_diag_agent.log_parser import (
    cluster_errors,
    extract_stack_fragments,
    parse_log_text,
    summarize_log,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def enable_mock(monkeypatch):
    """所有测试都使用 Mock 模式。"""
    ru.set_mock_mode(True)
    yield
    ru.set_mock_mode(False)


# ── ros2_utils 测试 ────────────────────────────────────────────────────────────

def test_list_nodes_returns_nodes():
    result = ru.list_nodes()
    assert "is_error" not in result
    assert "/diff_drive_controller" in result["output"]


def test_list_topics_includes_cmd_vel():
    result = ru.list_topics()
    assert "is_error" not in result
    assert "/cmd_vel" in result["output"]
    assert "geometry_msgs/msg/Twist" in result["output"]


def test_topic_info_known_topic():
    result = ru.topic_info("/cmd_vel")
    assert "is_error" not in result
    assert "Publisher count" in result["info"]


def test_topic_info_unknown_topic():
    result = ru.topic_info("/nonexistent_topic")
    # Mock 模式下返回"not found"提示，不是 is_error
    assert "not found" in result.get("info", "").lower() or "is_error" not in result


def test_topic_echo_once_known():
    result = ru.topic_echo_once("/cmd_vel")
    assert "is_error" not in result
    assert "linear" in result["output"]


def test_topic_echo_once_unknown():
    result = ru.topic_echo_once("/no_such_topic")
    assert "No mock data" in result["output"]


def test_node_info_known():
    result = ru.node_info("/diff_drive_controller")
    assert "is_error" not in result
    assert "wheel_separation" in result["output"]


def test_list_params_known():
    result = ru.list_params("/diff_drive_controller")
    assert "is_error" not in result
    assert "wheel_radius" in result["output"]


def test_get_param_known():
    result = ru.get_param("/diff_drive_controller", "wheel_separation")
    assert "is_error" not in result
    assert "0.5" in result["output"]


def test_tf_frames_contains_base_link():
    result = ru.tf_frames()
    assert "is_error" not in result
    assert "base_link" in result["output"]


def test_check_tf_known_frames():
    result = ru.check_tf("odom", "base_link")
    assert "is_error" not in result
    assert "Translation" in result["output"]


def test_check_tf_unknown_frame():
    result = ru.check_tf("odom", "totally_unknown_frame")
    assert result.get("is_error") is True


def test_ros2_doctor_contains_warnings():
    result = ru.ros2_doctor()
    assert "is_error" not in result
    assert "WARN" in result["output"]


def test_grep_logs_mock():
    result = ru.grep_logs("ERROR")
    assert "is_error" not in result
    assert len(result["matches"]) > 0


def test_run_diagnostic_script_not_in_allowlist():
    result = ru.run_diagnostic_script("/tmp/malicious.sh")
    assert result.get("is_error") is True
    assert "allowlist" in result["message"].lower()


def test_run_diagnostic_script_in_allowlist():
    result = ru.run_diagnostic_script("/opt/scripts/ros2_check_network.sh")
    assert "is_error" not in result
    assert "Mock" in result["output"]


# ── log_parser 测试 ────────────────────────────────────────────────────────────

SAMPLE_LOG = """\
[1700000001.000000] [INFO] [my_node]: Starting up
[1700000002.000000] [ERROR] [my_node]: Failed to connect to /dev/ttyUSB0: No such file
[1700000003.000000] [ERROR] [my_node]: Failed to connect to /dev/ttyUSB0: No such file
[1700000004.000000] [WARN] [my_node]: Retrying connection...
[1700000005.000000] [FATAL] [my_node]: Cannot initialize hardware
[1700000006.000000] [ERROR] [other_node]: Transform lookup failed: base_link to map
"""


def test_parse_log_text_count():
    entries = parse_log_text(SAMPLE_LOG)
    assert len(entries) == 6


def test_parse_log_levels():
    entries = parse_log_text(SAMPLE_LOG)
    levels = {e.level for e in entries}
    assert levels == {"INFO", "ERROR", "WARN", "FATAL"}


def test_cluster_errors_deduplicates():
    entries = parse_log_text(SAMPLE_LOG)
    clusters = cluster_errors(entries)
    # "Failed to connect to /dev/ttyUSB0: No such file" should be clustered as one
    patterns = [c.pattern for c in clusters]
    assert any("connect" in p for p in patterns)
    # The repeated error should have count >= 2
    connect_cluster = next(
        (c for c in clusters if "connect" in c.pattern.lower()), None
    )
    assert connect_cluster is not None
    assert connect_cluster.count == 2


def test_extract_stack_fragments():
    text = """\
[1700000010.000000] [ERROR] [my_node]: Unhandled exception:
  Traceback (most recent call last):
    File "node.py", line 42, in callback
      result = process(data)
    File "process.py", line 10, in process
      raise ValueError("bad data")
  ValueError: bad data
"""
    frags = extract_stack_fragments(text)
    assert len(frags) > 0
    assert "Traceback" in frags[0]


def test_summarize_log_structure():
    summary = summarize_log(SAMPLE_LOG)
    assert "total_lines" in summary
    assert "level_counts" in summary
    assert "error_clusters" in summary
    assert summary["level_counts"].get("ERROR", 0) >= 2
    assert summary["level_counts"].get("FATAL", 0) >= 1


def test_summarize_log_with_sample_file():
    """使用 examples/sample_log.txt 测试完整解析流程。"""
    import os
    sample = os.path.join(
        os.path.dirname(__file__), "..", "examples", "sample_log.txt"
    )
    with open(sample, encoding="utf-8") as f:
        content = f.read()
    summary = summarize_log(content)
    assert summary["total_lines"] > 10
    assert summary["level_counts"].get("ERROR", 0) > 0
    assert len(summary["error_clusters"]) > 0
